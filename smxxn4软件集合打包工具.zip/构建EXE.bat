@echo off
chcp 65001 >nul
title 构建 EXE
cd /d "%~dp0"

echo ============================================
echo   软件集合打包工具 - 构建 Windows EXE
echo ============================================
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到 Python
    pause
    exit /b 1
)

REM 检查/安装 PyInstaller
python -c "import PyInstaller" >nul 2>&1
if errorlevel 1 (
    echo 正在安装 PyInstaller...
    pip install pyinstaller
    if errorlevel 1 (
        echo [错误] PyInstaller 安装失败
        pause
        exit /b 1
    )
)

echo 正在构建 EXE...
echo.

python -m PyInstaller ^
    --onefile ^
    --windowed ^
    --name "软件集合打包工具" ^
    --add-data "data.json;." ^
    --noconfirm ^
    --clean ^
    bundler.py

if errorlevel 1 (
    echo.
    echo [错误] 构建失败
    pause
    exit /b 1
)

echo.
echo ============================================
echo   构建成功！
echo   EXE 位置: dist\软件集合打包工具.exe
echo ============================================
echo.

REM 打开输出目录
explorer dist

pause
