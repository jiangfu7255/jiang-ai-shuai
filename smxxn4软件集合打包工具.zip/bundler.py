# -*- coding: utf-8 -*-
"""
软件集合打包工具 v3
修复：zip打包、临时目录、PS1函数作用域、弹窗居中、便携包主程序指定
"""

import json
import os
import sys
import uuid
import shutil
import subprocess
import tempfile
import textwrap
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import zipfile

# ─── 常量 ───────────────────────────────────────────────────────────────────

DATA_FILE = Path(__file__).parent / "data.json"
SCRIPT_DIR = Path(__file__).parent

SOFTWARE_TYPES = {
    "url":      "下载地址",
    "local":    "安装包 (exe/msi)",
    "portable": "便携包 (文件夹)",
    "folder":   "普通文件夹",
}

DEFAULT_SILENT_ARGS = {
    "url": "/silent",
    "local": "/quiet /norestart",
    "portable": "",
    "folder": "",
}

# ─── 数据层 ─────────────────────────────────────────────────────────────────

def new_id():
    return uuid.uuid4().hex[:8]

def load_data():
    if DATA_FILE.exists():
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"categories": [], "installer_title": "软件合集", "installer_output": "Setup.exe"}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ─── 生成独立安装器 ──────────────────────────────────────────────────────────

def generate_installer(data, output_dir: Path, as_exe: bool = True):
    """
    生成独立安装器。
    1. 先在临时工作目录生成所有文件
    2. 复制到用户选择的输出目录
    3. 如果 as_exe=True，尝试打包为 EXE，失败则打 zip
    """
    title = data.get("installer_title", "软件合集")
    categories = data.get("categories", [])

    # 收集所有软件
    all_items = []
    for cat in categories:
        for item in cat.get("items", []):
            all_items.append({**item, "category": cat["name"]})

    if not all_items:
        raise ValueError("没有添加任何软件，无法生成安装器")

    # ── 在临时工作目录中构建 ──
    work_dir = Path(tempfile.mkdtemp(prefix="bundler_"))
    try:
        assets_dir = work_dir / "assets"
        assets_dir.mkdir()

        # 复制本地文件到 assets
        item_assets = {}
        for item in all_items:
            if item["type"] in ("local", "portable", "folder") and os.path.exists(item["value"]):
                src = Path(item["value"])
                dest = assets_dir / src.name
                if src.is_dir():
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(src, dest)
                else:
                    shutil.copy2(src, dest)
                item_assets[item["id"]] = f"assets\\{src.name}"

        # 生成 PS1
        ps1_content = _build_ps1_script(title, all_items, item_assets)
        ps1_path = work_dir / "installer.ps1"
        with open(ps1_path, "w", encoding="utf-8-sig") as f:
            f.write(ps1_content)

        # 生成 BAT
        bat_content = (
            f'@echo off\r\n'
            f'chcp 65001 >nul\r\n'
            f'title {title}\r\n'
            f'powershell -ExecutionPolicy Bypass -File "%~dp0installer.ps1"\r\n'
            f'pause\r\n'
        )
        bat_path = work_dir / "启动安装器.bat"
        with open(bat_path, "w", encoding="utf-8-sig") as f:
            f.write(bat_content)

        # ── 尝试 IExpress 打包 EXE ──
        exe_result = None
        if as_exe:
            exe_path = work_dir / data.get("installer_output", "Setup.exe")
            if _try_iexpress(work_dir, ps1_path, exe_path, title) and exe_path.exists():
                exe_result = exe_path

        # ── 复制到用户输出目录 ──
        output_dir.mkdir(parents=True, exist_ok=True)

        if exe_result:
            # EXE 成功，只复制 exe
            dest = output_dir / exe_result.name
            shutil.copy2(exe_result, dest)
            return dest
        else:
            # 复制所有文件到输出目录
            for item in work_dir.iterdir():
                dest = output_dir / item.name
                if item.is_dir():
                    if dest.exists():
                        shutil.rmtree(dest)
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)

            if as_exe:
                # 打 zip（只包含工作目录的文件，不遍历输出目录）
                zip_name = data.get("installer_output", "Setup.exe").replace(".exe", ".zip")
                zip_path = output_dir / zip_name
                _create_zip(work_dir, zip_path)
                return zip_path
            else:
                return output_dir / "installer.ps1"

    finally:
        # 清理临时目录
        shutil.rmtree(work_dir, ignore_errors=True)


def _build_ps1_script(title, all_items, item_assets):
    """构建完整的 PowerShell 安装器脚本"""

    # 软件列表条目
    sw_entries = []
    for item in all_items:
        val = item["value"]
        if item["id"] in item_assets:
            val = item_assets[item["id"]]
        sw_entries.append(
            '    @{{ Id="{}"; Name="{}"; Category="{}"; Type="{}"; '
            'Value="{}"; SilentArgs="{}"; PortableExe="{}" }}'.format(
                item["id"],
                item["name"].replace('"', '`"'),
                item["category"].replace('"', '`"'),
                item["type"],
                val.replace('"', '`"'),
                item.get("silent_args", "").replace('"', '`"'),
                item.get("portable_exe", "").replace('"', '`"'),
            )
        )
    sw_array = ",\n".join(sw_entries)

    # 用普通字符串拼接（避免 f-string 与 PowerShell $() 冲突）
    lines = []
    lines.append('#Requires -Version 5.1')
    lines.append('<#')
    lines.append(f'.SYNOPSIS')
    lines.append(f'    {title} - 自动安装器')
    lines.append(f'.DESCRIPTION')
    lines.append(f'    由软件集合打包工具生成')
    lines.append(f'#>')
    lines.append('')
    lines.append('[CmdletBinding()]')
    lines.append('param()')
    lines.append('')
    lines.append('$ErrorActionPreference = "Stop"')
    lines.append('[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12')
    lines.append('Add-Type -AssemblyName System.Windows.Forms')
    lines.append('Add-Type -AssemblyName System.Drawing')
    lines.append('[System.Windows.Forms.Application]::EnableVisualStyles()')
    lines.append('')
    lines.append('$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path')
    lines.append('')

    # 软件列表
    lines.append('# ─── 软件列表 ────────────────────────────')
    lines.append('$SoftwareList = @(')
    lines.append(sw_array)
    lines.append(')')
    lines.append('')

    # 全局安装函数（放在顶层，避免作用域问题）
    lines.append('# ─── 安装函数（顶层定义） ────────────────')
    lines.append('function Invoke-SoftwareInstall($sw) {')
    lines.append('    $LblStatus.Text = "正在处理: $($sw.Name) ..."')
    lines.append('    $LblStatus.Refresh()')
    lines.append('')
    lines.append('    switch ($sw.Type) {')
    lines.append('        "url" {')
    lines.append('            $ext = "exe"')
    lines.append('            if ($sw.Value -match "\\.msi") { $ext = "msi" }')
    lines.append('            $downloadPath = Join-Path $TempDir "$($sw.Name -replace \'[^\\w]\',\'_\').$ext"')
    lines.append('            try {')
    lines.append('                $LblStatus.Text = "正在下载: $($sw.Name) ..."')
    lines.append('                $LblStatus.Refresh()')
    lines.append('                $wc = New-Object System.Net.WebClient')
    lines.append('                $wc.DownloadFile($sw.Value, $downloadPath)')
    lines.append('                $LblStatus.Text = "正在安装: $($sw.Name) ..."')
    lines.append('                $LblStatus.Refresh()')
    lines.append('                if ($ext -eq "msi") {')
    lines.append('                    Start-Process "msiexec.exe" -ArgumentList "/i `"$downloadPath`" $($sw.SilentArgs) /qn" -Wait -NoNewWindow')
    lines.append('                } else {')
    lines.append('                    Start-Process $downloadPath -ArgumentList $sw.SilentArgs -Wait -NoNewWindow')
    lines.append('                }')
    lines.append('                return $true')
    lines.append('            } catch {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("下载或安装失败: $($sw.Name)`n$($_.Exception.Message)", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('        }')
    lines.append('        "local" {')
    lines.append('            $src = Join-Path $ScriptDir $sw.Value')
    lines.append('            if (!(Test-Path $src)) { $src = $sw.Value }')
    lines.append('            if (!(Test-Path $src)) {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("找不到文件: $($sw.Value)", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('            try {')
    lines.append('                $ext = [System.IO.Path]::GetExtension($src).ToLower()')
    lines.append('                if ($ext -eq ".msi") {')
    lines.append('                    Start-Process "msiexec.exe" -ArgumentList "/i `"$src`" $($sw.SilentArgs) /qn" -Wait -NoNewWindow')
    lines.append('                } else {')
    lines.append('                    Start-Process $src -ArgumentList $sw.SilentArgs -Wait -NoNewWindow')
    lines.append('                }')
    lines.append('                return $true')
    lines.append('            } catch {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("安装失败: $($sw.Name)`n$($_.Exception.Message)", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('        }')
    lines.append('        "portable" {')
    lines.append('            $src = Join-Path $ScriptDir $sw.Value')
    lines.append('            if (!(Test-Path $src)) { $src = $sw.Value }')
    lines.append('            if (!(Test-Path $src)) {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("找不到文件夹: $src", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('            try {')
    lines.append('                $exePath = $null')
    lines.append('                if ($sw.PortableExe -and (Test-Path (Join-Path $src $sw.PortableExe))) {')
    lines.append('                    $exePath = Join-Path $src $sw.PortableExe')
    lines.append('                } else {')
    lines.append('                    $exePath = (Get-ChildItem $src -Filter "*.exe" -Recurse | Select-Object -First 1).FullName')
    lines.append('                }')
    lines.append('                if ($exePath) {')
    lines.append('                    $shortcutPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "$($sw.Name).lnk"')
    lines.append('                    $shell = New-Object -ComObject WScript.Shell')
    lines.append('                    $shortcut = $shell.CreateShortcut($shortcutPath)')
    lines.append('                    $shortcut.TargetPath = $exePath')
    lines.append('                    $shortcut.WorkingDirectory = (Split-Path $exePath)')
    lines.append('                    $shortcut.Save()')
    lines.append('                }')
    lines.append('                return $true')
    lines.append('            } catch {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("创建快捷方式失败: $($sw.Name)`n$($_.Exception.Message)", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('        }')
    lines.append('        "folder" {')
    lines.append('            $src = Join-Path $ScriptDir $sw.Value')
    lines.append('            if (!(Test-Path $src)) { $src = $sw.Value }')
    lines.append('            if (!(Test-Path $src)) {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("找不到文件夹: $src", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('            try {')
    lines.append('                $dest = Join-Path ([Environment]::GetFolderPath("Desktop")) (Split-Path $src -Leaf)')
    lines.append('                if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }')
    lines.append('                Copy-Item $src $dest -Recurse')
    lines.append('                return $true')
    lines.append('            } catch {')
    lines.append('                [System.Windows.Forms.MessageBox]::Show("复制失败: $($sw.Name)`n$($_.Exception.Message)", "错误", "OK", "Error")')
    lines.append('                return $false')
    lines.append('            }')
    lines.append('        }')
    lines.append('    }')
    lines.append('    return $false')
    lines.append('}')
    lines.append('')

    # GUI
    lines.append('# ─── 主窗口 ──────────────────────────────')
    lines.append('$Form = New-Object System.Windows.Forms.Form')
    lines.append(f'$Form.Text = "{title}"')
    lines.append('$Form.Size = New-Object System.Drawing.Size(740, 580)')
    lines.append('$Form.StartPosition = "CenterScreen"')
    lines.append('$Form.FormBorderStyle = "FixedSingle"')
    lines.append('$Form.MaximizeBox = $false')
    lines.append('$Form.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 9)')
    lines.append('$Form.BackColor = [System.Drawing.Color]::FromArgb(245, 245, 245)')
    lines.append('')

    # 标题区
    lines.append('# ─── 标题区 ──────────────────────────────')
    lines.append('$PanelTop = New-Object System.Windows.Forms.Panel')
    lines.append('$PanelTop.Size = New-Object System.Drawing.Size(720, 60)')
    lines.append('$PanelTop.Location = New-Object System.Drawing.Point(10, 10)')
    lines.append('$PanelTop.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 215)')
    lines.append('$Form.Controls.Add($PanelTop)')
    lines.append('')
    lines.append('$LblTitle = New-Object System.Windows.Forms.Label')
    lines.append(f'$LblTitle.Text = "  {title}"')
    lines.append('$LblTitle.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 16, [System.Drawing.FontStyle]::Bold)')
    lines.append('$LblTitle.ForeColor = [System.Drawing.Color]::White')
    lines.append('$LblTitle.AutoSize = $true')
    lines.append('$LblTitle.Location = New-Object System.Drawing.Point(10, 12)')
    lines.append('$PanelTop.Controls.Add($LblTitle)')
    lines.append('')
    lines.append('$LblDesc = New-Object System.Windows.Forms.Label')
    lines.append('$LblDesc.Text = "勾选需要安装的软件，然后点击「开始安装」"')
    lines.append('$LblDesc.AutoSize = $true')
    lines.append('$LblDesc.ForeColor = [System.Drawing.Color]::FromArgb(200, 200, 200)')
    lines.append('$LblDesc.Location = New-Object System.Drawing.Point(14, 40)')
    lines.append('$PanelTop.Controls.Add($LblDesc)')
    lines.append('')

    # CheckedListBox
    lines.append('# ─── CheckedListBox ──────────────────────')
    lines.append('$CheckedList = New-Object System.Windows.Forms.CheckedListBox')
    lines.append('$CheckedList.Location = New-Object System.Drawing.Point(10, 80)')
    lines.append('$CheckedList.Size = New-Object System.Drawing.Size(704, 380)')
    lines.append('$CheckedList.CheckOnClick = $true')
    lines.append('$CheckedList.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 10)')
    lines.append('$CheckedList.BackColor = [System.Drawing.Color]::White')
    lines.append('$CheckedList.BorderStyle = "FixedSingle"')
    lines.append('')
    lines.append('$currentCategory = ""')
    lines.append('foreach ($sw in $SoftwareList) {')
    lines.append('    if ($sw.Category -ne $currentCategory) {')
    lines.append('        $currentCategory = $sw.Category')
    lines.append('        $CheckedList.Items.Add("─── $currentCategory ───", $false) | Out-Null')
    lines.append('    }')
    lines.append('    $CheckedList.Items.Add("  " + $sw.Name, $true) | Out-Null')
    lines.append('}')
    lines.append('$Form.Controls.Add($CheckedList)')
    lines.append('')

    # 底部按钮区
    lines.append('# ─── 底部按钮区 ──────────────────────────')
    lines.append('$PanelBottom = New-Object System.Windows.Forms.Panel')
    lines.append('$PanelBottom.Size = New-Object System.Drawing.Size(720, 55)')
    lines.append('$PanelBottom.Location = New-Object System.Drawing.Point(10, 468)')
    lines.append('$PanelBottom.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)')
    lines.append('$Form.Controls.Add($PanelBottom)')
    lines.append('')

    # 全选/全不选
    lines.append('$BtnSelectAll = New-Object System.Windows.Forms.Button')
    lines.append('$BtnSelectAll.Text = "全选"')
    lines.append('$BtnSelectAll.Size = New-Object System.Drawing.Size(65, 32)')
    lines.append('$BtnSelectAll.Location = New-Object System.Drawing.Point(10, 10)')
    lines.append('$BtnSelectAll.FlatStyle = "Flat"')
    lines.append('$BtnSelectAll.BackColor = [System.Drawing.Color]::White')
    lines.append('$BtnSelectAll.Add_Click({')
    lines.append('    for ($i = 0; $i -lt $CheckedList.Items.Count; $i++) {')
    lines.append('        if (!$CheckedList.Items[$i].StartsWith("───")) { $CheckedList.SetItemChecked($i, $true) }')
    lines.append('    }')
    lines.append('})')
    lines.append('$PanelBottom.Controls.Add($BtnSelectAll)')
    lines.append('')

    lines.append('$BtnSelectNone = New-Object System.Windows.Forms.Button')
    lines.append('$BtnSelectNone.Text = "全不选"')
    lines.append('$BtnSelectNone.Size = New-Object System.Drawing.Size(65, 32)')
    lines.append('$BtnSelectNone.Location = New-Object System.Drawing.Point(80, 10)')
    lines.append('$BtnSelectNone.FlatStyle = "Flat"')
    lines.append('$BtnSelectNone.BackColor = [System.Drawing.Color]::White')
    lines.append('$BtnSelectNone.Add_Click({')
    lines.append('    for ($i = 0; $i -lt $CheckedList.Items.Count; $i++) { $CheckedList.SetItemChecked($i, $false) }')
    lines.append('})')
    lines.append('$PanelBottom.Controls.Add($BtnSelectNone)')
    lines.append('')

    # 进度条
    lines.append('$ProgressBar = New-Object System.Windows.Forms.ProgressBar')
    lines.append('$ProgressBar.Location = New-Object System.Drawing.Point(160, 14)')
    lines.append('$ProgressBar.Size = New-Object System.Drawing.Size(350, 24)')
    lines.append('$ProgressBar.Style = "Continuous"')
    lines.append('$PanelBottom.Controls.Add($ProgressBar)')
    lines.append('')

    # 状态标签
    lines.append('$LblStatus = New-Object System.Windows.Forms.Label')
    lines.append('$LblStatus.Text = "就绪"')
    lines.append('$LblStatus.AutoSize = $true')
    lines.append('$LblStatus.Location = New-Object System.Drawing.Point(160, 42)')
    lines.append('$LblStatus.ForeColor = [System.Drawing.Color]::Gray')
    lines.append('$PanelBottom.Controls.Add($LblStatus)')
    lines.append('')

    # 安装按钮
    lines.append('$BtnInstall = New-Object System.Windows.Forms.Button')
    lines.append('$BtnInstall.Text = "▶ 开始安装"')
    lines.append('$BtnInstall.Size = New-Object System.Drawing.Size(170, 40)')
    lines.append('$BtnInstall.Location = New-Object System.Drawing.Point(540, 8)')
    lines.append('$BtnInstall.Font = New-Object System.Drawing.Font("Microsoft YaHei UI", 11, [System.Drawing.FontStyle]::Bold)')
    lines.append('$BtnInstall.BackColor = [System.Drawing.Color]::FromArgb(0, 120, 215)')
    lines.append('$BtnInstall.ForeColor = [System.Drawing.Color]::White')
    lines.append('$BtnInstall.FlatStyle = "Flat"')
    lines.append('$BtnInstall.Cursor = [System.Windows.Forms.Cursors]::Hand')
    lines.append('$PanelBottom.Controls.Add($BtnInstall)')
    lines.append('')

    # 临时目录
    lines.append('# ─── 临时目录 ────────────────────────────')
    lines.append('$TempDir = Join-Path $env:TEMP "SoftwareBundler_$(Get-Random)"')
    lines.append('New-Item -ItemType Directory -Path $TempDir -Force | Out-Null')
    lines.append('')

    # 按钮事件
    lines.append('# ─── 安装按钮事件 ────────────────────────')
    lines.append('$BtnInstall.Add_Click({')
    lines.append('    $toInstall = @()')
    lines.append('    $swIndex = 0')
    lines.append('    for ($i = 0; $i -lt $CheckedList.Items.Count; $i++) {')
    lines.append('        if ($CheckedList.Items[$i].StartsWith("───")) { $swIndex++; continue }')
    lines.append('        if ($CheckedList.GetItemChecked($i)) {')
    lines.append('            $toInstall += $SoftwareList[$swIndex]')
    lines.append('        }')
    lines.append('        $swIndex++')
    lines.append('    }')
    lines.append('')
    lines.append('    if ($toInstall.Count -eq 0) {')
    lines.append('        [System.Windows.Forms.MessageBox]::Show("请至少选择一个软件！", "提示", "OK", "Information")')
    lines.append('        return')
    lines.append('    }')
    lines.append('')
    lines.append('    $BtnInstall.Enabled = $false')
    lines.append('    $BtnSelectAll.Enabled = $false')
    lines.append('    $BtnSelectNone.Enabled = $false')
    lines.append('    $ProgressBar.Maximum = $toInstall.Count')
    lines.append('    $ProgressBar.Value = 0')
    lines.append('    $successCount = 0')
    lines.append('    $failCount = 0')
    lines.append('')
    lines.append('    foreach ($sw in $toInstall) {')
    lines.append('        $result = Invoke-SoftwareInstall $sw')
    lines.append('        if ($result) { $successCount++ } else { $failCount++ }')
    lines.append('        $ProgressBar.Value++')
    lines.append('        $Form.Refresh()')
    lines.append('    }')
    lines.append('')
    lines.append('    $LblStatus.Text = "完成！成功: $successCount, 失败: $failCount"')
    lines.append('    $BtnInstall.Enabled = $true')
    lines.append('    $BtnSelectAll.Enabled = $true')
    lines.append('    $BtnSelectNone.Enabled = $true')
    lines.append('')
    lines.append('    if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue }')
    lines.append('')
    lines.append('    $msg = "安装完成！`n成功: $successCount 个`n失败: $failCount 个"')
    lines.append('    if ($failCount -gt 0) { $msg += "`n`n部分软件安装失败，请查看状态信息。" }')
    lines.append('    [System.Windows.Forms.MessageBox]::Show($msg, "完成", "OK", "Information")')
    lines.append('})')
    lines.append('')

    # 窗口关闭清理
    lines.append('$Form.Add_FormClosing({')
    lines.append('    if (Test-Path $TempDir) { Remove-Item $TempDir -Recurse -Force -ErrorAction SilentlyContinue }')
    lines.append('})')
    lines.append('')

    # 显示
    lines.append('$Form.ShowDialog() | Out-Null')

    return "\r\n".join(lines)


def _try_iexpress(work_dir, ps1_path, exe_path, title):
    """尝试用 Windows IExpress 创建 EXE"""
    iexpress = Path(os.environ.get("SYSTEMROOT", "C:\\Windows")) / "System32" / "iexpress.exe"
    if not iexpress.exists():
        return False

    sed_content = (
        '[Version]\r\n'
        'Class=IEXPRESS\r\n'
        'SEDVersion=3\r\n'
        '[Options]\r\n'
        'PackagePurpose=InstallApp\r\n'
        'ShowInstallProgramWindow=0\r\n'
        'HideExtractAnimation=1\r\n'
        'UseLongFileName=1\r\n'
        'InsideCompressed=0\r\n'
        'CAB_FixedSize=0\r\n'
        'CAB_ResvCodeSigning=0\r\n'
        'RebootMode=N\r\n'
        'InstallPrompt=%InstallPrompt%\r\n'
        'DisplayLicense=%DisplayLicense%\r\n'
        'FinishMessage=%FinishMessage%\r\n'
        f'TargetName={exe_path}\r\n'
        f'FriendlyName={title}\r\n'
        'AppLaunched=powershell -ExecutionPolicy Bypass -File installer.ps1\r\n'
        'PostInstallCmd=\r\n'
        'FILE0="installer.ps1"\r\n'
        '[SourceFiles]\r\n'
        f'SourceFiles0={work_dir}\r\n'
        '[SourceFiles0]\r\n'
        '%FILE0%=\r\n'
    )

    sed_path = work_dir / "installer.sed"
    with open(sed_path, "w", encoding="utf-8") as f:
        f.write(sed_content)

    try:
        subprocess.run([str(iexpress), "/N", str(sed_path)], check=True, timeout=60)
        return exe_path.exists()
    except Exception:
        return False


def _create_zip(source_dir: Path, zip_path: Path):
    """将 source_dir 下的所有文件打成 zip"""
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            for f in files:
                fpath = Path(root) / f
                arcname = fpath.relative_to(source_dir)
                zf.write(fpath, arcname)


# ─── GUI ─────────────────────────────────────────────────────────────────────

class SoftwareBundlerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("软件集合打包工具")
        self.root.geometry("960x640")
        self.root.minsize(800, 500)
        self.root.configure(bg="#f5f5f5")

        self.data = load_data()
        self.selected_category_idx = None
        self.selected_item_idx = None

        self._build_ui()
        self._refresh_tree()

    # ─── UI 构建 ─────────────────────────────

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")

        ACCENT = "#0078d7"
        style.configure("Accent.TButton", background=ACCENT, foreground="white",
                         font=("Microsoft YaHei UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", "#005fa3")])
        style.configure("Danger.TButton", background="#d83b01", foreground="white")
        style.map("Danger.TButton", background=[("active", "#a52a00")])
        style.configure("Treeview", font=("Microsoft YaHei UI", 10), rowheight=28)
        style.configure("Treeview.Heading", font=("Microsoft YaHei UI", 9, "bold"))

        main = ttk.Frame(self.root, padding=10)
        main.pack(fill=tk.BOTH, expand=True)

        # ── 左侧 ──
        left = ttk.LabelFrame(main, text="  软件列表  ", padding=8)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        toolbar = ttk.Frame(left)
        toolbar.pack(fill=tk.X, pady=(0, 5))

        ttk.Button(toolbar, text="+ 添加分类", command=self._add_category).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="✏ 编辑分类", command=self._edit_category).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑 删除分类", command=self._delete_category,
                   style="Danger.TButton").pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        ttk.Button(toolbar, text="+ 添加软件", command=self._add_item,
                   style="Accent.TButton").pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="✏ 编辑软件", command=self._edit_item).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="🗑 删除软件", command=self._delete_item,
                   style="Danger.TButton").pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        ttk.Button(toolbar, text="↑", width=3, command=self._move_up).pack(side=tk.LEFT, padx=1)
        ttk.Button(toolbar, text="↓", width=3, command=self._move_down).pack(side=tk.LEFT, padx=1)

        tree_frame = ttk.Frame(left)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        self.tree = ttk.Treeview(tree_frame, columns=("type",), show="tree headings", selectmode="browse")
        self.tree.heading("#0", text="名称", anchor=tk.W)
        self.tree.heading("type", text="类型", anchor=tk.W)
        self.tree.column("#0", width=280, minwidth=200)
        self.tree.column("type", width=120, minwidth=80)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # ── 右侧 ──
        right = ttk.LabelFrame(main, text="  安装器配置  ", padding=12)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(5, 0), expand=False)
        right.configure(width=280)

        ttk.Label(right, text="安装器标题:").pack(anchor=tk.W, pady=(5, 2))
        self.title_var = tk.StringVar(value=self.data.get("installer_title", "软件合集"))
        ttk.Entry(right, textvariable=self.title_var, width=30).pack(fill=tk.X, pady=(0, 8))

        ttk.Label(right, text="输出文件名:").pack(anchor=tk.W, pady=(5, 2))
        self.output_var = tk.StringVar(value=self.data.get("installer_output", "Setup.exe"))
        ttk.Entry(right, textvariable=self.output_var, width=30).pack(fill=tk.X, pady=(0, 8))

        ttk.Separator(right, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=12)

        ttk.Label(right, text="软件数量:").pack(anchor=tk.W)
        self.count_label = ttk.Label(right, text="0 个软件",
                                     font=("Microsoft YaHei UI", 11, "bold"))
        self.count_label.pack(anchor=tk.W, pady=(2, 12))

        ttk.Separator(right, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=12)

        btn_frame = ttk.Frame(right)
        btn_frame.pack(fill=tk.X, pady=(10, 0))

        ttk.Button(btn_frame, text="💾 保存配置", command=self._save_config,
                   style="Accent.TButton").pack(fill=tk.X, pady=3)
        ttk.Button(btn_frame, text="📄 生成安装脚本 (PS1+BAT)",
                   command=self._generate_ps1).pack(fill=tk.X, pady=3)
        ttk.Button(btn_frame, text="📦 生成安装包 (ZIP)",
                   command=self._generate_zip, style="Accent.TButton").pack(fill=tk.X, pady=3)

        ttk.Separator(right, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=12)

        ttk.Label(right, text="说明:", font=("Microsoft YaHei UI", 8, "bold")).pack(anchor=tk.W)
        help_text = (
            "• 下载地址：运行时自动下载安装\n"
            "• 安装包：本地 exe/msi，静默安装\n"
            "• 便携包：文件夹，可指定主程序生成快捷方式\n"
            "• 普通文件夹：复制到桌面\n\n"
            "生成的安装包解压后双击 .bat 即可运行，\n"
            "无需安装 Python 或其他依赖。\n\n"
            "如需转为 EXE，在 Windows 上安装\n"
            "ps2exe 模块后可一键转换。"
        )
        ttk.Label(right, text=help_text, font=("Microsoft YaHei UI", 8),
                  foreground="#666", wraplength=250).pack(anchor=tk.W)

    # ─── 树形列表 ────────────────────────────

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        total = 0
        for cat_idx, cat in enumerate(self.data.get("categories", [])):
            cat_id = f"cat_{cat_idx}"
            self.tree.insert("", tk.END, iid=cat_id, text=f"📁 {cat['name']}",
                             values=("分类",), open=True)
            for item_idx, item in enumerate(cat.get("items", [])):
                item_id = f"item_{cat_idx}_{item_idx}"
                type_label = SOFTWARE_TYPES.get(item["type"], item["type"])
                self.tree.insert(cat_id, tk.END, iid=item_id,
                                 text=f"    {item['name']}", values=(type_label,))
                total += 1
        self.count_label.config(text=f"{total} 个软件")

    def _on_tree_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        iid = sel[0]
        parts = iid.split("_")
        if parts[0] == "cat":
            self.selected_category_idx = int(parts[1])
            self.selected_item_idx = None
        elif parts[0] == "item":
            self.selected_category_idx = int(parts[1])
            self.selected_item_idx = int(parts[2])

    # ─── 分类操作 ─────────────────────────────

    def _add_category(self):
        name = self._prompt("添加分类", "分类名称:")
        if name:
            self.data["categories"].append({"id": new_id(), "name": name, "items": []})
            self._refresh_tree()
            self._save()

    def _edit_category(self):
        if self.selected_category_idx is None:
            messagebox.showinfo("提示", "请先选择一个分类")
            return
        cat = self.data["categories"][self.selected_category_idx]
        name = self._prompt("编辑分类", "分类名称:", default=cat["name"])
        if name:
            cat["name"] = name
            self._refresh_tree()
            self._save()

    def _delete_category(self):
        if self.selected_category_idx is None:
            messagebox.showinfo("提示", "请先选择一个分类")
            return
        cat = self.data["categories"][self.selected_category_idx]
        count = len(cat.get("items", []))
        msg = f"确定删除分类「{cat['name']}」吗？"
        if count > 0:
            msg += f"\n\n该分类下有 {count} 个软件，将一并删除。"
        if messagebox.askyesno("确认删除", msg):
            self.data["categories"].pop(self.selected_category_idx)
            self.selected_category_idx = None
            self.selected_item_idx = None
            self._refresh_tree()
            self._save()

    # ─── 软件操作 ─────────────────────────────

    def _add_item(self):
        if not self.data["categories"]:
            messagebox.showinfo("提示", "请先添加一个分类")
            return
        dialog = ItemDialog(self.root, self.data["categories"], title="添加软件")
        self.root.wait_window(dialog.top)
        if dialog.result:
            cat_idx = dialog.result["category_idx"]
            self.data["categories"][cat_idx]["items"].append(dialog.result["item"])
            self._refresh_tree()
            self._save()

    def _edit_item(self):
        if self.selected_category_idx is None or self.selected_item_idx is None:
            messagebox.showinfo("提示", "请先选择一个软件")
            return
        cat = self.data["categories"][self.selected_category_idx]
        item = cat["items"][self.selected_item_idx]
        dialog = ItemDialog(self.root, self.data["categories"], title="编辑软件",
                            edit_item=item, edit_cat_idx=self.selected_category_idx)
        self.root.wait_window(dialog.top)
        if dialog.result:
            new_cat_idx = dialog.result["category_idx"]
            if new_cat_idx != self.selected_category_idx:
                cat["items"].pop(self.selected_item_idx)
                self.data["categories"][new_cat_idx]["items"].append(dialog.result["item"])
            else:
                cat["items"][self.selected_item_idx] = dialog.result["item"]
            self._refresh_tree()
            self._save()

    def _delete_item(self):
        if self.selected_category_idx is None or self.selected_item_idx is None:
            messagebox.showinfo("提示", "请先选择一个软件")
            return
        cat = self.data["categories"][self.selected_category_idx]
        item = cat["items"][self.selected_item_idx]
        if messagebox.askyesno("确认删除", f"确定删除「{item['name']}」吗？"):
            cat["items"].pop(self.selected_item_idx)
            self.selected_item_idx = None
            self._refresh_tree()
            self._save()

    def _move_up(self):
        if self.selected_category_idx is None or self.selected_item_idx is None:
            return
        items = self.data["categories"][self.selected_category_idx]["items"]
        idx = self.selected_item_idx
        if idx > 0:
            items[idx], items[idx - 1] = items[idx - 1], items[idx]
            self.selected_item_idx = idx - 1
            self._refresh_tree()
            self._save()
            self.tree.selection_set(f"item_{self.selected_category_idx}_{self.selected_item_idx}")

    def _move_down(self):
        if self.selected_category_idx is None or self.selected_item_idx is None:
            return
        items = self.data["categories"][self.selected_category_idx]["items"]
        idx = self.selected_item_idx
        if idx < len(items) - 1:
            items[idx], items[idx + 1] = items[idx + 1], items[idx]
            self.selected_item_idx = idx + 1
            self._refresh_tree()
            self._save()
            self.tree.selection_set(f"item_{self.selected_category_idx}_{self.selected_item_idx}")

    # ─── 生成 ─────────────────────────────────

    def _save_config(self):
        self.data["installer_title"] = self.title_var.get()
        self.data["installer_output"] = self.output_var.get()
        self._save()
        messagebox.showinfo("保存成功", "配置已保存！")

    def _generate_ps1(self):
        self.data["installer_title"] = self.title_var.get()
        self.data["installer_output"] = self.output_var.get()
        self._save()

        out_dir = filedialog.askdirectory(title="选择输出目录")
        if not out_dir:
            return
        try:
            result = generate_installer(self.data, Path(out_dir), as_exe=False)
            messagebox.showinfo("生成成功",
                f"安装脚本已生成:\n{result}\n\n"
                f"使用方法：\n"
                f"1. 将整个输出文件夹复制到目标电脑\n"
                f"2. 双击「启动安装器.bat」运行\n\n"
                f"如需转为 EXE：\n"
                f"在 Windows PowerShell 中执行：\n"
                f"Install-Module ps2exe -Force\n"
                f"Invoke-ps2exe installer.ps1 Setup.exe")
        except Exception as e:
            messagebox.showerror("生成失败", str(e))

    def _generate_zip(self):
        self.data["installer_title"] = self.title_var.get()
        self.data["installer_output"] = self.output_var.get()
        self._save()

        out_dir = filedialog.askdirectory(title="选择输出目录")
        if not out_dir:
            return
        try:
            result = generate_installer(self.data, Path(out_dir), as_exe=True)
            if str(result).endswith(".zip"):
                messagebox.showinfo("生成成功",
                    f"安装包已生成:\n{result}\n\n"
                    f"将 zip 解压后，双击「启动安装器.bat」即可运行。\n\n"
                    f"如果需要转为 EXE，解压后在 Windows 中执行：\n"
                    f"Install-Module ps2exe -Force\n"
                    f"Invoke-ps2exe installer.ps1 Setup.exe")
            else:
                messagebox.showinfo("生成成功", f"EXE 安装包已生成:\n{result}")
        except Exception as e:
            messagebox.showerror("生成失败", str(e))

    # ─── 工具 ─────────────────────────────────

    def _save(self):
        save_data(self.data)

    def _prompt(self, title, label, default=""):
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("350x130")
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(dialog, text=label).pack(pady=(15, 5), padx=15, anchor=tk.W)
        var = tk.StringVar(value=default)
        entry = ttk.Entry(dialog, textvariable=var, width=35)
        entry.pack(padx=15)
        entry.select_range(0, tk.END)
        entry.focus_set()

        result = [None]

        def on_ok():
            result[0] = var.get().strip()
            dialog.destroy()

        def on_cancel():
            dialog.destroy()

        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="确定", command=on_ok,
                   style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="取消", command=on_cancel).pack(side=tk.LEFT, padx=5)

        entry.bind("<Return>", lambda e: on_ok())
        dialog.bind("<Escape>", lambda e: on_cancel())

        self._center_on_parent(dialog)
        self.root.wait_window(dialog)
        return result[0]

    def _center_on_parent(self, child):
        child.update_idletasks()
        px = self.root.winfo_x()
        py = self.root.winfo_y()
        pw = self.root.winfo_width()
        ph = self.root.winfo_height()
        cw = child.winfo_width()
        ch = child.winfo_height()
        x = px + (pw - cw) // 2
        y = py + (ph - ch) // 2
        child.geometry(f"+{x}+{y}")


class ItemDialog:
    """添加/编辑软件的弹窗"""
    def __init__(self, parent, categories, title="添加软件", edit_item=None, edit_cat_idx=0):
        self.top = tk.Toplevel(parent)
        self.top.title(title)
        self.top.geometry("520x420")
        self.top.resizable(False, False)
        self.top.transient(parent)
        self.top.grab_set()

        self.result = None
        self.categories = categories
        self.parent = parent

        frame = ttk.Frame(self.top, padding=15)
        frame.pack(fill=tk.BOTH, expand=True)

        # 分类选择
        ttk.Label(frame, text="所属分类:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.cat_var = tk.StringVar()
        cat_names = [c["name"] for c in categories]
        cat_combo = ttk.Combobox(frame, textvariable=self.cat_var, values=cat_names,
                                 state="readonly", width=28)
        cat_combo.grid(row=0, column=1, sticky=tk.EW, pady=5, padx=(8, 0))
        if cat_names:
            cat_combo.current(edit_cat_idx if edit_cat_idx < len(cat_names) else 0)

        # 名称
        ttk.Label(frame, text="软件名称:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.name_var = tk.StringVar(value=edit_item["name"] if edit_item else "")
        ttk.Entry(frame, textvariable=self.name_var, width=30).grid(
            row=1, column=1, sticky=tk.EW, pady=5, padx=(8, 0))

        # 类型
        ttk.Label(frame, text="软件类型:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.type_var = tk.StringVar()
        type_names = list(SOFTWARE_TYPES.values())
        type_keys = list(SOFTWARE_TYPES.keys())
        type_combo = ttk.Combobox(frame, textvariable=self.type_var, values=type_names,
                                  state="readonly", width=28)
        type_combo.grid(row=2, column=1, sticky=tk.EW, pady=5, padx=(8, 0))
        type_combo.bind("<<ComboboxSelected>>", self._on_type_change)

        if edit_item:
            idx = type_keys.index(edit_item["type"]) if edit_item["type"] in type_keys else 0
            type_combo.current(idx)
        else:
            type_combo.current(0)

        # 值
        ttk.Label(frame, text="地址/路径:").grid(row=3, column=0, sticky=tk.W, pady=5)
        val_frame = ttk.Frame(frame)
        val_frame.grid(row=3, column=1, sticky=tk.EW, pady=5, padx=(8, 0))

        self.value_var = tk.StringVar(value=edit_item["value"] if edit_item else "")
        self.value_entry = ttk.Entry(val_frame, textvariable=self.value_var, width=31)
        self.value_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.browse_btn = ttk.Button(val_frame, text="浏览", command=self._browse, width=5)
        self.browse_btn.pack(side=tk.LEFT, padx=(4, 0))

        # 便携包主程序
        ttk.Label(frame, text="主程序路径:").grid(row=4, column=0, sticky=tk.W, pady=5)
        exe_frame = ttk.Frame(frame)
        exe_frame.grid(row=4, column=1, sticky=tk.EW, pady=5, padx=(8, 0))

        self.portable_exe_var = tk.StringVar(
            value=edit_item.get("portable_exe", "") if edit_item else "")
        self.portable_exe_entry = ttk.Entry(exe_frame, textvariable=self.portable_exe_var, width=31)
        self.portable_exe_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.exe_browse_btn = ttk.Button(exe_frame, text="浏览", command=self._browse_exe, width=5)
        self.exe_browse_btn.pack(side=tk.LEFT, padx=(4, 0))

        ttk.Label(frame, text="（便携包专用，相对路径，如 bin\\app.exe）",
                  font=("Microsoft YaHei UI", 8), foreground="#999").grid(
            row=5, column=1, sticky=tk.W, padx=(8, 0))

        # 静默参数
        ttk.Label(frame, text="静默参数:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.silent_var = tk.StringVar(
            value=edit_item.get("silent_args", "") if edit_item else "")
        ttk.Entry(frame, textvariable=self.silent_var, width=30).grid(
            row=6, column=1, sticky=tk.EW, pady=5, padx=(8, 0))

        ttk.Label(frame, text="（exe/msi 静默安装参数，如 /S /quiet）",
                  font=("Microsoft YaHei UI", 8), foreground="#999").grid(
            row=7, column=1, sticky=tk.W, padx=(8, 0))

        frame.columnconfigure(1, weight=1)

        # 按钮
        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=8, column=0, columnspan=2, pady=15)
        ttk.Button(btn_frame, text="确定", command=self._on_ok,
                   style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="取消", command=self._on_cancel).pack(side=tk.LEFT, padx=5)

        self._current_type = type_keys[edit_item["type"]] if edit_item and edit_item["type"] in type_keys else "url"
        self._on_type_change(None)

        self._center_on_parent()

    def _center_on_parent(self):
        self.top.update_idletasks()
        px = self.parent.winfo_x()
        py = self.parent.winfo_y()
        pw = self.parent.winfo_width()
        ph = self.parent.winfo_height()
        cw = self.top.winfo_width()
        ch = self.top.winfo_height()
        x = px + (pw - cw) // 2
        y = py + (ph - ch) // 2
        self.top.geometry(f"+{x}+{y}")

    def _on_type_change(self, event):
        type_keys = list(SOFTWARE_TYPES.keys())
        type_names = list(SOFTWARE_TYPES.values())
        idx = type_names.index(self.type_var.get()) if self.type_var.get() in type_names else 0
        key = type_keys[idx]
        self._current_type = key

        if key in ("local", "portable", "folder"):
            self.browse_btn.config(state="normal")
        else:
            self.browse_btn.config(state="disabled")

        if key == "portable":
            self.portable_exe_entry.config(state="normal")
            self.exe_browse_btn.config(state="normal")
        else:
            self.portable_exe_entry.config(state="disabled")
            self.exe_browse_btn.config(state="disabled")

        if not self.silent_var.get():
            self.silent_var.set(DEFAULT_SILENT_ARGS.get(key, ""))

    def _browse(self):
        if self._current_type == "local":
            path = filedialog.askopenfilename(
                title="选择安装包",
                filetypes=[("安装包", "*.exe *.msi"), ("所有文件", "*.*")]
            )
        else:
            path = filedialog.askdirectory(title="选择文件夹")
        if path:
            self.value_var.set(path)

    def _browse_exe(self):
        folder = self.value_var.get().strip()
        if not folder or not os.path.isdir(folder):
            messagebox.showwarning("提示", "请先填写便携包文件夹路径", parent=self.top)
            return
        path = filedialog.askopenfilename(
            title="选择主程序",
            initialdir=folder,
            filetypes=[("可执行文件", "*.exe"), ("所有文件", "*.*")],
            parent=self.top
        )
        if path:
            try:
                rel = os.path.relpath(path, folder)
                self.portable_exe_var.set(rel)
            except ValueError:
                self.portable_exe_var.set(path)

    def _on_ok(self):
        name = self.name_var.get().strip()
        if not name:
            messagebox.showwarning("提示", "请输入软件名称", parent=self.top)
            return

        type_keys = list(SOFTWARE_TYPES.keys())
        type_names = list(SOFTWARE_TYPES.values())
        idx = type_names.index(self.type_var.get()) if self.type_var.get() in type_names else 0
        sw_type = type_keys[idx]

        value = self.value_var.get().strip()
        if not value:
            messagebox.showwarning("提示", "请输入地址或路径", parent=self.top)
            return

        cat_names = [c["name"] for c in self.categories]
        cat_idx = cat_names.index(self.cat_var.get()) if self.cat_var.get() in cat_names else 0

        self.result = {
            "category_idx": cat_idx,
            "item": {
                "id": new_id(),
                "name": name,
                "type": sw_type,
                "value": value,
                "silent_args": self.silent_var.get().strip(),
                "portable_exe": self.portable_exe_var.get().strip(),
            }
        }
        self.top.destroy()

    def _on_cancel(self):
        self.top.destroy()


# ─── 入口 ────────────────────────────────────────────────────────────────────

def main():
    root = tk.Tk()
    icon_path = SCRIPT_DIR / "icon.ico"
    if icon_path.exists():
        try:
            root.iconbitmap(icon_path)
        except Exception:
            pass
    app = SoftwareBundlerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
