@echo off
chcp 65001 >nul
title 软件集合打包工具
cd /d "%~dp0"
python bundler.py
if errorlevel 1 (
    echo.
    echo [错误] 未找到 Python，请先安装 Python 3.8+
    echo 下载地址: https://www.python.org/downloads/
    echo 安装时请勾选 "Add Python to PATH"
    echo.
    pause
)
