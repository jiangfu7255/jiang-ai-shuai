# 软件集合打包工具

将多个软件打包为一个可执行安装器，支持在 Windows 上一键批量安装。

## 功能

### 软件类型支持

| 类型 | 说明 |
|------|------|
| 下载地址 | 保留 URL，安装器运行时自动下载并安装 |
| 安装包 (exe/msi) | 本地安装包，静默安装 |
| 便携包 (文件夹) | 文件夹形式的便携软件，自动创建桌面快捷方式 |
| 普通文件夹 | 直接复制到桌面 |

### 管理功能

- 添加/删除软件，支持分类管理
- 软件排序（上移/下移，同分类内移动）
- 分类的添加/修改/删除
- 安装器标题和输出文件名自定义

### 安装器特性

- 生成的安装器为独立 EXE，无需安装 Python
- 图形界面，用户可勾选需要安装的软件
- 自动下载、静默安装、进度显示
- 支持全选/全不选

## 使用方法

### 运行打包工具

```bash
python bundler.py
```

### 添加软件

1. 点击「添加分类」创建分类（如：浏览器、开发工具）
2. 选中分类后点击「添加软件」
3. 填写软件名称、类型、地址/路径、静默参数

### 生成安装包

1. 在右侧配置安装器标题和输出文件名
2. 点击「生成 PS1 脚本」生成 PowerShell 安装脚本
3. 点击「生成 EXE 安装包」转换为可执行文件（需要 ps2exe 模块）

## 静默安装参数参考

| 软件 | 静默参数 |
|------|----------|
| Chrome | `/silent /install` |
| Firefox | `-ms` |
| VS Code | `/verysilent /mergetasks=!runcode` |
| 7-Zip | `/S` |
| Notepad++ | `/S` |
| WinRAR | `/S` |
| .NET (exe) | `/quiet /norestart` |
| MSI 安装包 | `/quiet /norestart` (使用 msiexec) |

## 依赖

- Python 3.8+
- tkinter（Python 内置）
- ps2exe（可选，用于生成 EXE）

```powershell
# 安装 ps2exe（在 Windows PowerShell 中运行）
Install-Module -Name ps2exe -Force -Scope CurrentUser
```

## 文件说明

```
software-bundler/
├── bundler.py      # 主程序
├── data.json       # 软件数据（自动生成）
└── README.md       # 说明文档
```
